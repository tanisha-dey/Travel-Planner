import { V, _ } from "../chunks/2.C9v7AvWq.js";
export {
  V as component,
  _ as universal
};
